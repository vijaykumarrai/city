package com.word.search;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

public class WordSearch {

	public static void main(String[] args) {
		if (args == null || args.length != 2 || args[0] == null || args[1] == null) {
			System.out.println("No inputs provided for the master word and dictionary.");
			// System.exit(0);
			return;
		}
		String masterWord = args[0].trim();
		String fileName = args[1].trim();

		Set<String> patterns = SearchUtil.getPatterns(masterWord);

		Set<String> result = new HashSet<>();

		try (Stream<String> stream = Files.lines(Paths.get(fileName))) {
			stream.forEach((word) -> {
				if (patterns.contains(word.trim())) {
					if (!result.contains(word.trim())) {
						System.out.println(word.trim());
						result.add(word.trim());
					}
				}
			});
		} catch (IOException e) {
			System.out.println("Cannot find input file.");
			System.exit(0);
		} catch (Exception e) {
			System.out.println("Cannot process the file for dictionary.");
			System.exit(0);
		}
	}
}
