package com.word.search;

public class WordSearchTest {

	public static void main(String[] args) {
		// success case
		System.out.println("==========================================================");
		System.out.println("Case 1 : success case : - should print {d, dg, gd}.");
		String[] input = new String[2];
		input[0] = "doog";
		input[1] = "dictionary.txt";
		WordSearch.main(input);

		// duplicate removal case
		System.out.println("==========================================================");
		System.out.println("Case 2 : remove duplicates : - should print {d, go, dog, god, good, dg, gd}.");
		input[0] = "doog";
		input[1] = "dictionary_duplicate.txt";
		WordSearch.main(input);

		// blank lines removal case
		System.out.println("==========================================================");
		System.out.println("Case 3 : remove  empty lines : - should print {d, go, dog, god, dg, gd}.");
		input[0] = "doog";
		input[1] = "dictionary_blank_lines.txt";
		WordSearch.main(input);

		// blank lines removal case
		System.out.println("==========================================================");
		System.out.println("Case 4 : empty file : - should print nothing and no errors.");
		input[0] = "doog";
		input[1] = "dictionary_empty_file.txt";
		WordSearch.main(input);

		// no arguments
		System.out.println("==========================================================");
		System.out
				.println("Case 5 : no arguments - should print No inputs provided for the master word and dictionary.");
		input = null;
		WordSearch.main(input);

		// null value for master word
		System.out.println("==========================================================");
		System.out.println(
				"Case 6 : null value for master card - should print No inputs provided for the master word and dictionary.");
		input = new String[2];
		input[0] = null;
		input[1] = "abc.txt";
		WordSearch.main(input);

		// null value for dictionary file
		System.out.println("==========================================================");
		System.out.println(
				"Case 7 : null value for dictionary file - should print No inputs provided for the master word and dictionary.");
		input = new String[2];
		input[0] = "god";
		input[1] = null;
		WordSearch.main(input);

		// invalid dictionary file
		System.out.println("==========================================================");
		input = new String[2];
		input[0] = "god";
		input[1] = "abc.txt";
		System.out.println("Case 8 : null value for dictionary file - should print Cannot find input file..");
		WordSearch.main(input);
		System.out.println("==========================================================");
	}
}
