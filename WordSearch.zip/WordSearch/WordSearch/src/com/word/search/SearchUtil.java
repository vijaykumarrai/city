package com.word.search;

import java.util.HashSet;
import java.util.Set;

public class SearchUtil {
	/**
	 * Get all combinations of letters from the given masterword.
	 * e.g. :- for dog, subsequences are d, do, dg, dog, god, odg etc.
	 * 
	 * @param masterWord
	 * @return Set<String> containing patterns
	 */
	public static Set<String> getPatterns(String masterWord) {
		Set<String> result = new HashSet<>();
		getDistinctPermutations(masterWord, "", result);
		Set<String> result1 = new HashSet<>();
		for (String r : result) {
			getAllSubSequences(r, result1);
		}
		return result1;
	}

	/**
	 * Get the list of permutations from the given string.
	 * Returns strings of same length as the input masterWord, but characters are rearranged.
	 * 
	 * @param masterWord
	 * @param answer
	 * @param result
	 */
	static void getDistinctPermutations(String masterWord, String answer, Set<String> result) {
		if (masterWord.length() == 0) {
			result.add(answer);
			return;
		}

		boolean alphabets[] = new boolean[26];

		for (int i = 0; i < masterWord.length(); i++) {
			char letter = masterWord.charAt(i);
			String subString = masterWord.substring(0, i) + masterWord.substring(i + 1);
			if (alphabets[letter - 'a'] == false)
				getDistinctPermutations(subString, answer + letter, result);
			alphabets[letter - 'a'] = true;
		}
	}

	/**
	 * Get all subsequences for the given input.
	 * Initial method to invoke the recursive method.
	 * 
	 * @param input
	 * @param result
	 */
	public static void getAllSubSequences(String input, Set<String> result) {
		int index = -1;
		String current = "";

		findSubSequences(input, input.length(), index, current, result);
	}

	/**
	 * Recursive method to find the subsequences for the given input.
	 * 
	 * @param input
	 * @param inputLength
	 * @param index
	 * @param current
	 * @param result
	 */
	public static void findSubSequences(String input, int inputLength, int index, String current, Set<String> result) {
		if (index == inputLength) {
			return;
		}
		if (current != null && current.length() != 0)
			result.add(current);

		for (int i = index + 1; i < inputLength; i++) {
			current += input.charAt(i);
			findSubSequences(input, inputLength, i, current, result);

			current = current.substring(0, current.length() - 1);
		}
	}
}
