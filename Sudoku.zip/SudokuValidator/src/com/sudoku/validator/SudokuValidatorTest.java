package com.sudoku.validator;

public class SudokuValidatorTest {

	public static void main(String[] args) {

		System.out.println("TC1: Success case");
		int board1[][] = { { 5, 3, 0, 0, 7, 0, 0, 0, 0 }, { 6, 0, 0, 1, 9, 5, 0, 0, 0 }, { 0, 9, 8, 0, 0, 0, 0, 6, 0 },
				{ 8, 0, 0, 0, 6, 0, 0, 0, 3 }, { 4, 0, 0, 8, 0, 3, 0, 0, 1 }, { 7, 0, 0, 0, 2, 0, 0, 0, 6 },
				{ 0, 6, 0, 0, 0, 0, 2, 8, 0 }, { 0, 0, 0, 4, 1, 9, 0, 0, 5 }, { 1, 0, 0, 0, 8, 0, 0, 7, 9 } };
		boolean result = SudokuValidator.isValidSudoku(board1);
		System.out.println("Result = " + result);
		System.out.println(result ? "Passed." : "Failed.");
		System.out.println("===================================================");

		System.out.println("TC2: Failure case");
		int board2[][] = { { 5, 3, 5, 0, 7, 0, 0, 0, 0 }, { 6, 0, 0, 1, 9, 5, 0, 0, 0 }, { 0, 9, 8, 0, 0, 0, 0, 6, 0 },
				{ 8, 0, 0, 0, 6, 0, 0, 0, 3 }, { 4, 0, 0, 8, 0, 3, 0, 0, 1 }, { 7, 0, 0, 0, 2, 0, 0, 0, 6 },
				{ 0, 6, 0, 0, 0, 0, 2, 8, 0 }, { 0, 0, 0, 4, 1, 9, 0, 0, 5 }, { 1, 0, 0, 0, 8, 0, 0, 7, 9 } };
		result = SudokuValidator.isValidSudoku(board2);
		System.out.println("Result = " + result);
		System.out.println(!result ? "Passed." : "Failed.");
		System.out.println("===================================================");

		System.out.println("TC3: Success case - Partially filled, but valid");
		int board3[][] = new int[9][9];
		board3[0][0] = 1;
		result = SudokuValidator.isValidSudoku(board3);
		System.out.println("Result = " + result);
		System.out.println(result ? "Passed." : "Failed.");
		System.out.println("===================================================");

		System.out.println("TC4: Failure case - Partially filled, but invalid");
		int board4[][] = new int[9][9];
		board4[0][0] = 1;
		board4[0][1] = 1;
		result = SudokuValidator.isValidSudoku(board4);
		System.out.println("Result = " + result);
		System.out.println(!result ? "Passed." : "Failed.");
		System.out.println("===================================================");
	}
}
