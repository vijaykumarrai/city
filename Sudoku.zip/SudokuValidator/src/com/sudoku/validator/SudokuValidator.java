package com.sudoku.validator;

import java.util.HashSet;
import java.util.Set;

public class SudokuValidator {
	private static int SUDOKU_SIZE = 9;

	/**
	 * takes int[][] as input containing sudoku entries and validates if the
	 * entries are valid.
	 * 
	 * @param entries
	 * @param n
	 * @return boolean
	 */
	public static boolean isValidSudoku(int entries[][]) {
		for (int row = 0; row < SUDOKU_SIZE; row++) {
			for (int column = 0; column < SUDOKU_SIZE; column++) {
				boolean notInRow = validateRow(entries, row);
				boolean notInColumn = validateColumn(entries, column);
				boolean notInBox = validate3x3Box(entries, row - row % 3, column - column % 3);

				if (!(notInRow && notInColumn && notInBox))
					return false;
			}
		}
		return true;
	}

	/**
	 * validate row entries.
	 * 
	 * @param input
	 * @param row
	 * @return boolean
	 */
	public static boolean validateRow(int input[][], int row) {
		Set<Integer> entries = new HashSet<>();

		for (int i = 0; i < 9; i++) {
			if (entries.contains(input[row][i]))
				return false;
			if (input[row][i] != 0)
				entries.add(input[row][i]);
		}
		return true;
	}

	/**
	 * validates column
	 * 
	 * @param input
	 * @param column
	 * @return
	 */
	static boolean validateColumn(int input[][], int column) {
		Set<Integer> entries = new HashSet<>();

		for (int i = 0; i < 9; i++) {
			if (entries.contains(input[i][column]))
				return false;

			if (input[i][column] != 0)
				entries.add(input[i][column]);
		}
		return true;
	}

	/**
	 * validate 3X3 box
	 * 
	 * @param input
	 * @param startRow
	 * @param startCol
	 * @return boolean
	 */
	static boolean validate3x3Box(int input[][], int startRow, int startCol) {
		Set<Integer> entries = new HashSet<>();

		for (int row = 0; row < 3; row++) {
			for (int column = 0; column < 3; column++) {
				int current = input[row + startRow][column + startCol];

				if (entries.contains(current))
					return false;
				if (current != 0)
					entries.add(current);
			}
		}
		return true;
	}
}


